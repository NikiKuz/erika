pip install requests
pip install configparser
pip uninstall python-telegram-bot
pip install python-telegram-bot==13.0

Токен бота нужно вставить в BOT_TOKEN в файле main.py

Ваш телеграм id нужно вставить в ALLOWED_CHAT_ID, 
если оставить None, то любой юзер сможет пользоваться ботом (не рекомендуется)

myfavoritelike_bot