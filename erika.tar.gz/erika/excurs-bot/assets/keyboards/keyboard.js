export const keyboard = {
    reply_markup: JSON.stringify({
        inline_keyboard: [
           [{text: "Записаться на экскурсию", callback_data: "excurs"}]
        ]
    })
}
